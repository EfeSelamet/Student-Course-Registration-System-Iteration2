public abstract class Person {
	
	private String fullName;
	private String ID;


	public Person(String fullName, String ID){
		this.fullName = fullName;
		this.ID = ID;
	}
	public Person(){
		
	}
	public String getID() {
		return ID;
	}


	public String getFullName() {
		return fullName;
	}
	public abstract void mainMenu(UserInterface userInterface);
	
}
