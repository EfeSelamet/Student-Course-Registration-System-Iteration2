import org.json.JSONArray;
import org.json.JSONObject;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class RegistrationController {

	private static RegistrationController registrationController;

	private ArrayList<Course> allCourses = new ArrayList<>();
	private ArrayList<Classroom> allClassrooms=new ArrayList<>();


	public RegistrationController() {
		this.registrationController = this;
		String filePathClassRoom = "jsonfiles/classrooms.json";


            FileReader reader = null;
            try {
                reader = new FileReader(filePathClassRoom);
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
            Scanner scanner = new Scanner(reader);
			StringBuilder jsonContent = new StringBuilder();

			while (scanner.hasNextLine()) {
				jsonContent.append(scanner.nextLine());
			}
			scanner.close();
			JSONArray crArray = new JSONArray(jsonContent.toString());

			for (int i = 0; i < crArray.length(); i++) {
				JSONObject cr = crArray.getJSONObject(i);

				String name = cr.getString("name");
				String capacity = cr.getString("capacity");
				allClassrooms.add(new Classroom(Integer.parseInt(capacity),name));

			}







		String filePathCourse = "jsonfiles/courses.json";


		CourseJsonHandler csj = new CourseJsonHandler();

		// Create an ArrayList to store course codes
		ArrayList<String> courseCodes = new ArrayList<>();

		try {
			reader = new FileReader(filePathCourse);
		} catch (FileNotFoundException e) {
			throw new RuntimeException(e);
		}
		scanner = new Scanner(reader);
		jsonContent = new StringBuilder();

		while (scanner.hasNextLine()) {
			jsonContent.append(scanner.nextLine());
		}
		scanner.close();
		JSONArray cArray = new JSONArray(jsonContent.toString());

		for (int i = 0; i < cArray.length(); i++) {
			JSONObject c = cArray.getJSONObject(i);

			String name = c.getString("code");

			courseCodes.add(name);

		}




		for(String s:courseCodes){

			ArrayList<String> infos = csj.retrieveInfo(s);


			Course course = new Course();
			course.setName(infos.get(1));
			course.setYear(infos.get(2));
			course.setCourseCode(s);

			String[] sections = infos.get(3).split("_");

			for(String se:sections){

				CourseSection cs = new CourseSection();
				String[] seInf = se.split(";");
				cs.setSectionNumber(Integer.parseInt(seInf[0]));
				cs.setId(s+"."+seInf[0]);
				cs.setDay(seInf[1]);
				cs.setHour(seInf[2]);
				cs.setCourse(course);
				
				
				
				for(Classroom ca : allClassrooms){
					if(ca.getRoomID().equals(seInf[3])){
						
						ca.addCourseSection(cs);
						cs.setClassroom(ca);
					}
				}

				course.addCourseSection(cs);




			}
			allCourses.add(course);
			String[] preReqsString = infos.get(4).split("-");
			
			if(preReqsString.length>=1&&!preReqsString[0].equals("")){
				for(String pre :preReqsString ){
					Course p = new Course();
					p.setCourseCode(pre);
					ArrayList<String> inf2 = csj.retrieveInfo(pre);

					p.setName(inf2.get(1));
					p.setYear(inf2.get(2));
					course.addPrerequisite(p);

				}
			}








		}








	}


	// All courses and classrooms will be created

	public ArrayList<Course> getAvailableCourses(Student student) {
		return student.getAvailableCourses(allCourses);
	}

	public void sendSelectedCourses(ArrayList<CourseSection> selectedCourses) {
		Student currentPerson = (Student) LoginSystemController.getLoginSystem().getCurrentUser();
		currentPerson.updateSelectedCourses(selectedCourses);

		UserJsonHandler userJsonHandler = new UserJsonHandler();
		userJsonHandler.writeAllSelectedCourses(currentPerson, selectedCourses);
	}

	public static RegistrationController getRegistrationController() {
		return registrationController;
	}


	public CourseSection getCourseSectionFromId(String id) {
		for (Course c : allCourses) {
			for (CourseSection cs : c.getCourseSections()) {
				if (cs.getId().equals(id)) {
					return cs;
				}
			}
		}
		return null;
	}

	public Course getCourseFromId(String id) {
		for (Course c : allCourses) {
			if (c.getCourseCode().equals(id)) {
				return c;
			}
		}
		return null;
	}

	public ArrayList<Course> getAllCourses() {
		return allCourses;
	}
	public ArrayList<Classroom> getAllClassrooms(){
		return allClassrooms;
	}
}
