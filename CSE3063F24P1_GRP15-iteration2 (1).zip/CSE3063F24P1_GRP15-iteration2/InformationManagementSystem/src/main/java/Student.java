import java.util.ArrayList;
import java.util.HashMap;

public class Student extends Person {

	private Advisor advisor;
	private Transcript transcript;
	

	public Student(ArrayList<String> infos,String studentId) {
		super(infos.get(1),studentId);
		this.transcript =createTranscript(infos.get(3),infos.get(4),infos.get(5));


	}
	

	public void updateSelectedCourses(ArrayList<CourseSection> selectedCourses) {
		for (CourseSection section : selectedCourses) {
			if(section.getCapacity()>section.getNumberOfStudents()){
				transcript.addSelectedCourse(section);
				section.setNumberOfStudents(section.getNumberOfStudents()+1);
			}
			else{
				section.getwaitingStudents().add(this);
			}

		}
	}

	public ArrayList<Course> getAvailableCourses(ArrayList<Course> allCourses){
		ArrayList<Course>  availableCourses= new ArrayList<Course>();
		for (Course course : allCourses) {
			if (course.checkPrerequisites(this)) 
				availableCourses.add(course);
		}
		return availableCourses;
	}

	public Advisor getAdvisor(){
		return advisor;
	}
	
	public Transcript getTranscript(){
		return transcript;
	}
	public ArrayList<CourseSection> retrieveSelectedCourses(){
		return transcript.getSelectedCourses();
	}

	public void setAdvisor(Advisor advisor) {
		this.advisor = advisor;
	}

	private Transcript createTranscript(String selected,String verified,String finished) {
		RegistrationController registrationController = RegistrationController.getRegistrationController();
		String[] selectedCourseSection = selected.split(",");
		String[] verifiedCourseSection = verified.split(",");
		String[] finishedCourse = finished.split(",");

		ArrayList<CourseSection> selectedCourseSectionList = new ArrayList<CourseSection>();
		ArrayList<CourseSection> verifiedCourseSectionList = new ArrayList<CourseSection>();
		HashMap<Course,Float> map = new HashMap<>();

		for(String courseSectionID: selectedCourseSection)
		{	

			if(courseSectionID == "")
				continue;
			selectedCourseSectionList.add(registrationController.getCourseSectionFromId(courseSectionID));
		}
		for(String courseSectionID: verifiedCourseSection)
		{
			System.out.println(courseSectionID);
			if(courseSectionID == "")
				continue;
			verifiedCourseSectionList.add(registrationController.getCourseSectionFromId(courseSectionID));
		}

		for(String courseID: finishedCourse)
		{	
			if(courseID == "")
				continue;
			Float courseGrade = Float.parseFloat(courseID.split("-")[1]);
			Course fc = registrationController.getCourseFromId(courseID.split("-")[0]) ;
			map.put(fc,courseGrade);
		}

		Transcript trans = new Transcript(selectedCourseSectionList,verifiedCourseSectionList,map,this);
		return trans;

	}

	@Override
	public void mainMenu(UserInterface userInterface) {
		userInterface.StudentMainScreen();
	}
}
