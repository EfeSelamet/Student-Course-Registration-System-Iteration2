import java.util.*;
public class LoginSystemController {
	
	private Person currentUser;
	
	private static LoginSystemController loginSystem;
	public static LoginSystemController getLoginSystem() {
		return loginSystem;
	}
	
	public LoginSystemController()
	{
		loginSystem = this;
	}

	public boolean login(String userName, String password) {
		UserJsonHandler ujs = new UserJsonHandler();
		String userID=""+ujs.checkUser(userName, password);
		if(userID.equals("")) {
			return false;
		}
		currentUser = createUser(userID);
		return true;
	}
	public Person createUser(String userID) {
		UserJsonHandler ujs = new UserJsonHandler();
		ArrayList<String> info =ujs.retrieveInfo(userID);
		if(info.get(0).equals("student")){
			Student student = new Student(info,userID);
			Advisor advisor = (Advisor)createUser(info.get(2));
			student.setAdvisor(advisor);
			return student;
		}
		if(info.get(0).equals("advisor")){
			Advisor advisor = new Advisor(info,userID);
			String[] listOfStudentID = info.get(2).split(",");
			for (String studentID : listOfStudentID) 
			{
				Student student = createStudentWithoutAdvisor(studentID);
				advisor.addStudent(student);
			}
			return advisor;
		}
		if(info.get(0).equals("scheduler")){
			CourseScheduler courseScheduler = new CourseScheduler(info, userID);
			return courseScheduler;
		}

		return null;

	}

	private Student createStudentWithoutAdvisor(String userID)
	{
		UserJsonHandler ujs = new UserJsonHandler();
		ArrayList<String> info =ujs.retrieveInfo(userID);
		Student student = new Student(info,userID);
		return student;
	}

	public Person getCurrentUser() {
		return currentUser;
	}

    public void logOut() {
		currentUser = null;
    }
}
