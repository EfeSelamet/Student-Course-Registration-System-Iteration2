import java.util.ArrayList;

public class VerificationController {
    
    public VerificationController(){

    }
    public String viewStudentList(Advisor advisor){
        String studentList = "";
        int number = 1;
        ArrayList<Student> listOfStudents = advisor.getStudentList();
        for(Student student: listOfStudents){
            studentList += number + ". " +student.getID() + " " +  student.getFullName() + "\n";
            number++;
        }
        return studentList;
    }

    public String viewSelectedList(int studentIndex){
        String selectedCourses = "";
        Advisor advisor = (Advisor)LoginSystemController.getLoginSystem().getCurrentUser();
        ArrayList<Student> listOfStudent = advisor.getStudentList();

        if(studentIndex < 1 || studentIndex > listOfStudent.size()){
            System.out.println("invalid index");
            return "";
        }

        Student selectedStudent = listOfStudent.get(studentIndex-1);
        ArrayList<CourseSection> listOfSelectedCourses = selectedStudent.retrieveSelectedCourses();
        int number = 1;
        for(CourseSection course: listOfSelectedCourses){
            selectedCourses += number++ + ". " +course.getCourse().getCourseCode() + " " +  course.getCourse().getName() + " " + course.getSectionNumber() + " " + course.getDay() + " " + course.getHour() + " " + course.getClassroom().getRoomID() +"\n";
        }
        return selectedCourses;
    }

    public void sendVerifiedCourses(int studentIndex, int[] verifiedCourses){
        Advisor advisor = (Advisor)LoginSystemController.getLoginSystem().getCurrentUser();

        ArrayList<Student> listOfStudents = advisor.getStudentList();
        Student selectedStudent = listOfStudents.get(studentIndex);

        Transcript transcript = selectedStudent.getTranscript();

        ArrayList<CourseSection> listOfSelectedCourses = selectedStudent.retrieveSelectedCourses();

        ArrayList<CourseSection> listOfVerifiedCourses = new ArrayList<CourseSection>();
        for (int courseSection : verifiedCourses) {
            listOfVerifiedCourses.add(listOfSelectedCourses.get(courseSection));
        }
        advisor.sendVerifiedCourses(transcript, listOfVerifiedCourses);
    }


    public void sendRejectedCourses(int studentIndex, int[] rejectedCourses){
        Advisor advisor = (Advisor)LoginSystemController.getLoginSystem().getCurrentUser();

        ArrayList<Student> listOfStudents = advisor.getStudentList();
        Student selectedStudent = listOfStudents.get(studentIndex);

        Transcript transcript = selectedStudent.getTranscript();

        ArrayList<CourseSection> listOfSelectedCourses = selectedStudent.retrieveSelectedCourses();

        ArrayList<CourseSection> listOfRejectedCourses = new ArrayList<CourseSection>();
        for (int courseSection : rejectedCourses) {
            listOfRejectedCourses.add(listOfSelectedCourses.get(courseSection));
        }
        advisor.sendRejectedCourses(transcript, listOfRejectedCourses);
    }
}