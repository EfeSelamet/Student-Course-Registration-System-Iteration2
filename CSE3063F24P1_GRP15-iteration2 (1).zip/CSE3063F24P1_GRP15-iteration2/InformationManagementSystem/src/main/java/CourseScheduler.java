import java.util.ArrayList;

public class CourseScheduler extends Person{

	public CourseScheduler(ArrayList<String> info, String ID) {
		super(info.get(1), ID);
		
	}



	private boolean checkSemesterConflict(CourseSection section, String time, String date){
		return false;

	}



    public boolean editSectionTime(CourseSection section, String time, String date) {
        if(section.getClassroom().checkLocationConflict(time, date))
			return false;
		
		if(checkSemesterConflict(section, time, date))
			return false;

		section.setDay(date);
		section.setHour(time);

		CourseJsonHandler  courseJsonHandler= new CourseJsonHandler();
		courseJsonHandler.updateCourseSectionDateAndTime(section, date,time);

		return true;
    }

	public boolean addSection(String course,String capacity,String classroom,String hour ,String day){

		ArrayList<Course> listOfCourses= RegistrationController.getRegistrationController().getAllCourses();
		ArrayList<Classroom> allClassrooms = RegistrationController.getRegistrationController().getAllClassrooms();


		CourseJsonHandler csj = new CourseJsonHandler();
		for(Course c:listOfCourses){
			if(c.getCourseCode().equals(course)){


				for(Classroom cr:allClassrooms){
					if(cr.getRoomID().equals(classroom)){
						int n = c.getCourseSections().size();

						CourseSection cs = new CourseSection(day,hour,n+1,c,cr);
						c.addCourseSection(cs);
						cr.addCourseSection(cs);
						csj.writeNewCourseSection(cs);

						return true;
					}
				}




			}

		}


		return false;

	}

	@Override
	public void mainMenu(UserInterface userInterface) {
		userInterface.SchedulerMainScreen();
	}
	
}
