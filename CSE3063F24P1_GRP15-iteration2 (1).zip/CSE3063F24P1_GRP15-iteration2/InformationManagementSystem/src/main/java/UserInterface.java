import java.util.ArrayList;

import java.util.Scanner;

public class UserInterface {


	public static void main(String[] args) {
		UserInterface userInterface = new UserInterface();
		userInterface.loginScreen();
	}

	public UserInterface()
	{
		RegistrationController registrationController = new RegistrationController();
		LoginSystemController loginSystemController = new LoginSystemController();
	}
	private void courseRegistrationScreen(){
		Student currentPerson=(Student)LoginSystemController.getLoginSystem().getCurrentUser();
		ArrayList<Course> availableCourses = RegistrationController.getRegistrationController().getAvailableCourses(currentPerson);
		ArrayList<CourseSection> selectedCourseSections = new ArrayList<>();
		while(true){
		System.out.println("Usage");
		System.out.println("----------------------------");
		System.out.println("In order to add a course to selected courses list type : \"add 'course index in available courses list'\"");
		System.out.println("\texample: add 3");
		System.out.println("In order to remove a course from selected courses list type : \"remove 'course index in selected courses list'\"");
		System.out.println("\texample: remove 2");
		System.out.println("In order to confirm your courses type \"confirm\"\n");
		
		System.out.println("Available Courses");
		System.out.println("----------------------------");
		int[] courseSectionNumbers = new int[availableCourses.size()];
		
		int k=1;
		for (int i = 0; i < courseSectionNumbers.length; i++) {
			ArrayList<CourseSection> sections = availableCourses.get(i).getCourseSections();
			courseSectionNumbers[i] = sections.size();
			Course course = availableCourses.get(i);
			String name = course.getName();
			String code = course.getCourseCode();

			for (int j = 0; j < sections.size(); j++) {
				CourseSection section = sections.get(j);
				int sectionNumber = section.getSectionNumber();
				String day = section.getDay();
				String hour = section.getHour();
				System.out.printf("%d. %s.%d %s\n\t%s\n\t%s\n\n", k++, code, sectionNumber, name, day, hour);
			}
		}

	        System.out.println("\nSelected Courses");
	        System.out.println("----------------------------");
	        
	        k =1;
	        for (int i = 0; i < selectedCourseSections.size(); i++) {				
	            CourseSection section = selectedCourseSections.get(i);
				String sectionid = section.getId();
				String name = section.getCourse().getName();
	            String day = section.getDay();
	            String hour = section.getHour();
	            System.out.printf("%d. %s %s\n\t%s\n\t%s\n\n", k++, sectionid, name, day, hour);
	        }

	        Scanner scanner = new Scanner(System.in);
	        String input[] = scanner.nextLine().split(" ");

	        if(input.length == 1 && input[0].equals("confirm"))
	        {
	        	//currentPerson.getTranscript().setSelectedCourses(selectedCourseSections);
	        	RegistrationController.getRegistrationController().sendSelectedCourses(selectedCourseSections);//
	        	//currentPerson.setDemandedCourses(selectedCourses, selectedCourseSections);
	            loginScreen();
	        }
	            //UserInterface.registrationSystem.demandCourses(selectedCourses, (Student)UserInterface.loginSystem.getCurrentUser(), selectedCourseSections);
	           // UserInterface.loginSystem.logOut();

	        else if(input.length == 2 )
	        {
	            int courseIndex;
	            try 
	            {
	                courseIndex = Integer.parseInt(input[1]);    
	            } catch (NumberFormatException e) {
	                System.out.println("Course index must be an integer");
	                continue;
	            }

	            if(input[0].equals("add"))
	            {
	                boolean found = false;
	                for (int i = 0; i < courseSectionNumbers.length; i++) {
	                    if(courseIndex <= courseSectionNumbers[i])
	                    {
	                        Course selectedCourse = availableCourses.get(i);
	                        int selectedSection = courseIndex - 1;
	                        selectedCourseSections.add(selectedCourse.getCourseSections().get(selectedSection));
	                        //selectedCourseSections.add((selectedCourse.getSections().get(selectedSection)));
	                        availableCourses.remove(selectedCourse);
	                        found= true;
	                        break;
	                    }
	                    else
	                    {
	                        courseIndex -= courseSectionNumbers[i];
	                    }

	                }
	                if(!found)
	                    System.out.println("Invalid course index.");
	                continue;
	            }
	            else if(input[0].equals("remove"))
	            {   
	                courseIndex -= 1;
	                if (courseIndex >= selectedCourseSections.size())
	                {
	                    System.out.println("Invalid course index.");
	                    continue;
	                }
	                Course course = selectedCourseSections.get(courseIndex).getCourse();
	                selectedCourseSections.remove(courseIndex);
	                availableCourses.add(course);

	            }
	            else
	            {
	                System.out.println("Invalid input.");
	                continue;
	            }
	        }

	        else
	        {
	            System.out.println("Invalid input.");
	            continue;
	        }
	    }
		

		
	}

	private void loginScreen() {
		String username = "";
        String password = "";
        do {
        
        Scanner input = new Scanner(System.in);
        // take username input from user if username is empty or have whitespaces throw exception
        try{
        System.out.println("Please enter username:");
        
        username = input.nextLine();

        if (username.isEmpty()) {
            throw new IllegalArgumentException("Username cannot be empty.");
        }

        for (int i = 0; i < username.length(); i++) {
             if (username.charAt(i) == ' ')
                throw new IllegalArgumentException("Username cannot have white spaces.");
        }
        }

        catch(IllegalArgumentException e)
        {
            System.out.println("Error: " + e.getMessage());
        }

        // take username input from user if username is empty or have whitespaces throw exception
        try{
            System.out.println("Please enter password:");
            
            password = input.nextLine();
    
            if (password.isEmpty()) {
                throw new IllegalArgumentException("Password cannot be empty.");
            }
            }
    
            catch(IllegalArgumentException e)
            {
                System.out.println("Error: " + e.getMessage());
            }
        } while (!LoginSystemController.getLoginSystem().login(username, password));
        LoginSystemController.getLoginSystem().getCurrentUser().mainMenu(this);
		
	}

		private void viewWeeklySchedule (ArrayList<CourseSection> courses) {
		String schedule[][][]=new String[5][8][2];
        for(int i=0;i<schedule.length;i++) {
        	for(int j=0;j<schedule[0].length;j++) {
        		for(int k=0;k<schedule[0][0].length;k++) {
        			schedule[i][j][k]="";
        		}
        	}
        }
        
        for(int i=0;i<courses.size();i++) {
        	String timeString = courses.get(i).getHour();
        	int start=Integer.parseInt(timeString.substring(6, 8));
        	int length=start-Integer.parseInt(timeString.substring(0, 2))+1;
        	
        	int dayIndex=
        			(courses.get(i).getDay().equals("Monday"))?0:
        			(courses.get(i).getDay().equals("Tuesday"))?1:
        			(courses.get(i).getDay().equals("Wednesday"))?2:
        			(courses.get(i).getDay().equals("Thursday"))?3:4;
        	int hourIndex;
        	hourIndex=(start<13)?start-9:start-10;
        	
        	for(int a=0;a<length;a++) {
        		schedule[dayIndex][hourIndex+a][0]=courses.get(i).getCourse().getName()+"."+courses.get(i).getSectionNumber();
        		schedule[dayIndex][hourIndex+a][1]=courses.get(i).getClassroom().getRoomID()+"";
        	}
        }
        System.out.println("___________________________________________________________________________________________________________________");
        System.out.println(" schedule |09:00       |10:00       |11:00       |13:00       |14:00       |15:00       |16:00       |17:00       |");
        System.out.println("___________________________________________________________________________________________________________________");

        for (int i = 0; i < schedule.length; i++) {
			System.out.print(
					(i==0)?"  Monday  ":
							(i==1)?"  Tuesday ":
									(i==2)?" Wednesday":
											(i==3)?" Thursday ":"  Friday  ");

            for (int j = 0; j < schedule[i].length; j++) {
                System.out.print("|");
                System.out.printf("%-12s", schedule[i][j][0]);
                
            }
            System.out.println("|");
            System.out.print("          ");
            
            for (int j = 0; j < schedule[i].length; j++) {
                System.out.print("|");
                System.out.printf("%-12s", schedule[i][j][1]);
                
            }
            
            System.out.println("|");

            System.out.println("___________________________________________________________________________________________________________________");
        }
		
		
	}

	public void StudentMainScreen()
	{
		System.out.println("1.Course registration screen");
		System.out.println("2.View weekly schedule");
		System.out.println("3.Transcript");
		System.out.println("4.Log out");

		System.out.println("\nSelect an operation:");

		int index = 5;
		try {
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();
			index = Integer.parseInt(input);
			if(index > 4 || index < 0)
			 throw new Exception();
		} catch (Exception e) {
			System.out.println("\nInvalid input.");
		}

		Student student = (Student) LoginSystemController.getLoginSystem().getCurrentUser();
		switch (index) {
			case 1:
				courseRegistrationScreen();
				break;
			case 2:
				viewWeeklySchedule(student.getTranscript().getVerifiedCourses());
				StudentMainScreen();
				break;
			case 3:
				System.out.println(student.getTranscript().toString()); 
				StudentMainScreen();
				break;
			case 4:
				logOut();
			default:
				StudentMainScreen();
				break;
		}
	}

	public void AdvisorMainScreen()
	{
		System.out.println("1.Student course verification screen");
		System.out.println("2.Log out");

		System.out.println("\nSelect an operation:");

		int index = 3;
		try {
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();
			index = Integer.parseInt(input);
			if(index > 2 || index < 0)
			 throw new Exception();
		} catch (Exception e) {
			System.out.println("\nInvalid input.");
		}
		switch (index) {
			case 1:
				CourseVerificationScreen();
				break;
			case 2:
				logOut();
			default:
				AdvisorMainScreen();
				break;
		}
	}

	private void CourseVerificationScreen() {
		Advisor advisor = (Advisor)LoginSystemController.getLoginSystem().getCurrentUser();
		VerificationController verificationController = new VerificationController();
		System.out.println(verificationController.viewStudentList(advisor));

		int studentIndex = -1;
		try {
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();
			if(input.equals("q"))
				advisor.mainMenu(this);
			studentIndex = Integer.parseInt(input);
		} catch (Exception e) {
			System.out.println("Invalid input");
		}
		ArrayList<Student> listOfStudent =advisor.getStudentList();
		if(studentIndex < 1 || studentIndex > listOfStudent.size()){
            System.out.println("invalid index");
            CourseVerificationScreen();
			return;
        }
		Student student = advisor.getStudentList().get(studentIndex -1);
		Transcript regLog = student.getTranscript();
        ArrayList<CourseSection> demandedCourseSections = regLog.getSelectedCourses();
        ArrayList<CourseSection> verifiedCourseSections = new ArrayList<CourseSection>();
        ArrayList<CourseSection> rejectedCourseSections = new ArrayList<CourseSection>();
        
        while(true)
        {
        System.out.println("Usage");
        System.out.println("----------------------------");
        System.out.println("In order to verify a course chosen by the student type : \"verify 'course index'\"");
        System.out.println("\texample: verify 3");
        System.out.println("In order to remove a course from selected courses list type : \"reject 'course index'\"");
        System.out.println("\texample: reject 2");
        System.out.println("In order to confirm your choices type \"confirm\"\n");
        System.out.println("----------------------------\n");

        System.out.println("Courses chosen by the student:");
        int k =1;
        for (int i = 0; i < demandedCourseSections.size(); i++) {
            Course course = demandedCourseSections.get(i).getCourse();
			String name = course.getName();
			String code = course.getCourseCode();
			CourseSection section = demandedCourseSections.get(i);
			int sectionNumber = section.getSectionNumber();
			String day = section.getDay();
			String hour = section.getHour();
			String isVerified="";
            if(verifiedCourseSections.contains(section))
                isVerified = "(VERIFED)";
            else if(rejectedCourseSections.contains(section))
                isVerified = "(REJECTED)";
            System.out.printf("%d. %s.%d %s  %s\n  %s\n\t%s\n\n", k++, code, sectionNumber, name, isVerified, day, hour);
        }

        Scanner scanner = new Scanner(System.in);
        String input[] = scanner.nextLine().split(" ");

        if(input.length == 1 && input[0].equals("confirm"))
        {
			advisor.sendVerifiedCourses(regLog, verifiedCourseSections);
            advisor.sendRejectedCourses(regLog, rejectedCourseSections);
            advisor.mainMenu(this);
            break;
        }

        else if(input.length == 2 )
        {
            int courseIndex;
            try 
            {
                courseIndex = Integer.parseInt(input[1]) - 1;    
            } catch (NumberFormatException e) {
                System.out.println("Course index must be an integer");
                continue;
            }

            if (courseIndex >= demandedCourseSections.size() && courseIndex < 0) 
            {
                System.out.println("Invalid index.");
                continue;    
            }
            if(input[0].equals("verify"))
            {   
                if(!verifiedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    verifiedCourseSections.add(demandedCourseSections.get(courseIndex));
                }
                if(verifiedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    rejectedCourseSections.remove(demandedCourseSections.get(courseIndex));
                }
            }
            else if(input[0].equals("reject"))
            {   
                if(!rejectedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    rejectedCourseSections.add(demandedCourseSections.get(courseIndex));
                }
                if(rejectedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    verifiedCourseSections.remove(demandedCourseSections.get(courseIndex));
                }
            }
            else
            {
                System.out.println("Invalid input.");
                continue;
            }
        }

        else
        {
            System.out.println("Invalid input.");
            continue;
        }}
	}

	public void advisorVerificationScreen(Student student)
    {
        Transcript regLog = student.getTranscript();
		Advisor advisor = (Advisor) LoginSystemController.getLoginSystem().getCurrentUser();
        ArrayList<CourseSection> demandedCourseSections = regLog.getSelectedCourses();
        ArrayList<CourseSection> verifiedCourseSections = new ArrayList<CourseSection>();
        ArrayList<CourseSection> rejectedCourseSections = new ArrayList<CourseSection>();
        
        while(true)
        {
        System.out.println("Usage");
        System.out.println("----------------------------");
        System.out.println("In order to verify a course chosen by the student type : \"verify 'course index'\"");
        System.out.println("\texample: verify 3");
        System.out.println("In order to remove a course from selected courses list type : \"reject 'course index'\"");
        System.out.println("\texample: reject 2");
        System.out.println("In order to confirm your choices type \"confirm\"\n");
        System.out.println("----------------------------\n");

        System.out.println("Courses chosen by the student:");
        int k =1;
        for (int i = 0; i < demandedCourseSections.size(); i++) {
            Course course = demandedCourseSections.get(i).getCourse();
			String name = course.getName();
			String code = course.getCourseCode();
			CourseSection section = demandedCourseSections.get(i);
			int sectionNumber = section.getSectionNumber();
			String day = section.getDay();
			String hour = section.getHour();
			System.out.printf("%d. %s.%d %s\n\t%s\n\t%s\n\n", k++, code, sectionNumber, name, day, hour);
			String isVerified="";
            if(verifiedCourseSections.contains(section))
                isVerified = "(VERIFED)";
            else if(rejectedCourseSections.contains(section))
                isVerified = "(REJECTED)";
            System.out.printf("%d. %s.%d %s  %s\n  %s\n\t%s\n\n", k++, code, sectionNumber, name, isVerified, day, hour);
        }

        Scanner scanner = new Scanner(System.in);
        String input[] = scanner.nextLine().split(" ");

        if(input.length == 1 && input[0].equals("confirm"))
        {
            VerificationController verificationController = new VerificationController();
			advisor.sendVerifiedCourses(regLog, verifiedCourseSections);
            advisor.sendRejectedCourses(regLog, rejectedCourseSections);
            advisor.mainMenu(this);
            break;
        }

        else if(input.length == 2 )
        {
            int courseIndex;
            try 
            {
                courseIndex = Integer.parseInt(input[1]) - 1;    
            } catch (NumberFormatException e) {
                System.out.println("Course index must be an integer");
                continue;
            }

            if (courseIndex >= demandedCourseSections.size() && courseIndex < 0) 
            {
                System.out.println("Invalid index.");
                continue;    
            }
            if(input[0].equals("verify"))
            {   
                if(!verifiedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    verifiedCourseSections.add(demandedCourseSections.get(courseIndex));
                }
                if(verifiedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    rejectedCourseSections.remove(demandedCourseSections.get(courseIndex));
                }
            }
            else if(input[0].equals("reject"))
            {   
                if(!rejectedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    rejectedCourseSections.add(demandedCourseSections.get(courseIndex));
                }
                if(rejectedCourseSections.contains(demandedCourseSections.get(courseIndex)))
                {
                    verifiedCourseSections.remove(demandedCourseSections.get(courseIndex));
                }
            }
            else
            {
                System.out.println("Invalid input.");
                continue;
            }
        }

        else
        {
            System.out.println("Invalid input.");
            continue;
        }}
    }

	public void SchedulerMainScreen()
	{
		System.out.println("1.Manage Courses");
		System.out.println("2.Log out");

		System.out.println("\nSelect an operation:");

		int index = 3;
		try {
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();
			index = Integer.parseInt(input);
			if(index > 2 || index < 0)
			 throw new Exception();
		} catch (Exception e) {
			System.out.println("\nInvalid input.");
		}
		switch (index) {
			case 1:
				SceduleManagementScreen();
				break;
			case 2:
				logOut();
			default:
				SchedulerMainScreen();
				break;
		}
	}

	private void SceduleManagementScreen() {
		
		CourseScheduler currentPerson=(CourseScheduler) LoginSystemController.getLoginSystem().getCurrentUser();

		SchedulerController schedulerController = new SchedulerController();
		int selectedCourse = -1;

		String courseList = schedulerController.viewCourses();

		System.out.println(courseList);

		System.out.println("Choose a course:");
		int courseIndex =-1;
		try {
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();
			courseIndex = Integer.parseInt(input);
		} catch (Exception e) {
			System.out.println("\nInvalid input.");
		}

		schedulerController.viewCourseSections(courseIndex);

		System.out.println("Choose course section");
		int courseSection = -1;
		try {
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();
			courseSection = Integer.parseInt(input);
		} catch (Exception e) {
			System.out.println("\nInvalid input.");
		}


		String courseSectionList = schedulerController.viewCourseSections(courseIndex);

		System.out.println(courseSectionList);

		System.out.println("Choose an option:");
		System.out.println("1.Edit section capacity");
		System.out.println("2.Edit section day/time");
		System.out.println("3.Edit section class");




		int choice = -1;
		try {
			Scanner scanner = new Scanner(System.in);
			String input = scanner.nextLine();
			choice = Integer.parseInt(input);
			if(choice > 3 || choice < 0)
				throw new Exception();
		} catch (Exception e) {
			System.out.println("\nInvalid input.");
		}
		switch (choice) {
			case 1:
				int capacity =-1;
				System.out.println("Choose a capacity");
				try {
					Scanner scanner = new Scanner(System.in);
					String input = scanner.nextLine();
					capacity = Integer.parseInt(input);
					if(capacity < 0)
						throw new Exception();
				} catch (Exception e) {
					System.out.println("\nInvalid input.");
				}
				schedulerController.editSectionCapacity(courseIndex, courseSection, capacity);
				break;
			case 2:
			String day = "";
			String time = "";
			System.out.println("Enter day hour");
			try {
				Scanner scanner = new Scanner(System.in);
				String input = scanner.nextLine();
				String[] inptarr = input.split(" ");
				day = inptarr[0];
				time = inptarr[1];
				capacity = Integer.parseInt(input);
			} catch (Exception e) {
				System.out.println("\nInvalid input.");
			}
			schedulerController.editSectionTime(courseIndex, courseSection, time, day);
			break;
			case 3:
			String classroom = "";
			System.out.println("Enter day hour");
			try {
				Scanner scanner = new Scanner(System.in);
				classroom = scanner.nextLine();
			} catch (Exception e) {
				System.out.println("\nInvalid input.");
			}
			schedulerController.editSectionClass(courseIndex, courseSection, classroom);
			case 4:
				currentPerson.mainMenu(this);
			break;
		}



	}
	private void logOut() {
		LoginSystemController.getLoginSystem().logOut();
		loginScreen();
	}

}
