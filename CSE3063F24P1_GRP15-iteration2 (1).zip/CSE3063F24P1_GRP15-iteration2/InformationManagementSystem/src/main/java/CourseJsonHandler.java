import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

class CourseJsonHandler implements JsonHandler{

    public  ArrayList<String> retrieveInfo(String id)  {
        // Use FileReader and BufferedReader to read the JSON file
        String filePath = "jsonfiles/"+id+".json";
        ArrayList<String> result = new ArrayList<>();


        try {
            // Read the content of the JSON file as a string
            FileReader reader = new FileReader(filePath);
			Scanner scanner = new Scanner(reader);
			StringBuilder jsonContent = new StringBuilder();

			while (scanner.hasNextLine()) {
				jsonContent.append(scanner.nextLine());
			}
			scanner.close();
			JSONObject jsonObject = new JSONObject(jsonContent.toString());

            // Extract the course details
            String type = jsonObject.getString("type");
            String courseName = jsonObject.getString("courseName");
            String academicYear = jsonObject.getString("academicYear");

            // Create an ArrayList to store the result


            // Add the main course details to the result
            result.add(type);
            result.add(courseName);

            // Extract the course sections and format them as required
            JSONArray courseSections = jsonObject.getJSONArray("courseSections");
            StringBuilder sections = new StringBuilder();
            for (int i = 0; i < courseSections.length(); i++) {
                JSONObject section = courseSections.getJSONObject(i);
                String sectionNumber = section.getString("sectionNumber");
                String day = section.getString("day");
                String time = section.getString("time");
                String room = section.getString("room");

                // Append each section's details in the format: sectionNumber;day;time;room
                if (i > 0) {
                    sections.append("_");
                }
                sections.append(sectionNumber).append(";").append(day).append(";").append(time).append(";").append(room);
            }

            // Add the formatted sections to the result
            result.add(academicYear);
            result.add(sections.toString());

            JSONArray prerequisites= jsonObject.getJSONArray("prerequisites");


            ArrayList<String> ps = new ArrayList<>();
            StringBuilder prerequisitesString = new StringBuilder();
            for (int i = 0; i < prerequisites.length(); i++) {
                if (i > 0) {
                    prerequisitesString.append("-");
                }
                prerequisitesString.append(prerequisites.getString(i));
            }
            result.add(prerequisitesString.toString());

        } catch (IOException e) {
            System.err.println("Error reading the JSON file Course: " + e.getMessage());
        }
        return result;
    }


    public void writeCapacity(CourseSection cs,int newCapacity){
        String id = cs.getCourse().getCourseCode();
        String filePath = "jsonfiles/"+id+".json";
        try {
            // Read and parse the JSON file
            FileReader reader = new FileReader(filePath);
            StringBuilder jsonContent = new StringBuilder();
            int c;
            while ((c = reader.read()) != -1) {
                jsonContent.append((char) c);
            }
            reader.close();

            // Parse the content into a JSONObject
            JSONObject courseJson = new JSONObject(jsonContent.toString());

            // Access and modify the "selectedCourseSections" array
            JSONArray courseSections = courseJson.getJSONArray("courseSections");


            for (int i = 0; i < courseSections.length(); i++) {
                JSONObject section = courseSections.getJSONObject(i);
                if (section.getString("sectionNumber").equals(cs.getSectionNumber())) {

                    section.put("capacity", newCapacity);

                    break; // Exit the loop after updating
                }
            }


            // Write the updated JSONObject back to the file
            try (FileWriter writer = new FileWriter(filePath)) {
                writer.write(courseJson.toString(2));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }





    }
    public void writeClassroom(CourseSection cs,String newClassroom){
        String id = cs.getCourse().getCourseCode();
        String filePath = "jsonfiles/"+id+".json";
        try {
            // Read and parse the JSON file
            FileReader reader = new FileReader(filePath);
            StringBuilder jsonContent = new StringBuilder();
            int c;
            while ((c = reader.read()) != -1) {
                jsonContent.append((char) c);
            }
            reader.close();

            // Parse the content into a JSONObject
            JSONObject courseJson = new JSONObject(jsonContent.toString());

            // Access and modify the "selectedCourseSections" array
            JSONArray courseSections = courseJson.getJSONArray("courseSections");


            for (int i = 0; i < courseSections.length(); i++) {
                JSONObject section = courseSections.getJSONObject(i);
                if (section.getString("sectionNumber").equals(cs.getSectionNumber())) {

                    section.put("room", newClassroom);

                    break; // Exit the loop after updating
                }
            }


            // Write the updated JSONObject back to the file
            try (FileWriter writer = new FileWriter(filePath)) {
                writer.write(courseJson.toString(2));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void writeNewCourseSection(CourseSection cs){


        String id = cs.getCourse().getCourseCode();
        String filePath = "jsonfiles/"+id+".json";



        try {
            // Read and parse the JSON file
            FileReader reader = new FileReader(filePath);
            StringBuilder jsonContent = new StringBuilder();
            int c;
            while ((c = reader.read()) != -1) {
                jsonContent.append((char) c);
            }
            reader.close();

            // Parse the content into a JSONObject
            JSONObject courseJson = new JSONObject(jsonContent.toString());

            // Access and modify the "selectedCourseSections" array
            JSONArray courseSections = courseJson.getJSONArray("courseSections");



            JSONObject newSection = new JSONObject();

            newSection.put("sectionNumber",courseSections.length()+1);
            newSection.put("day", cs.getDay());
            newSection.put("time", cs.getHour());
            newSection.put("room", cs.getClassroom());
            newSection.put("capacity",cs.getCapacity());


            courseSections.put(newSection);




            // Write the updated JSONObject back to the file
            try (FileWriter writer = new FileWriter(filePath)) {
                writer.write(courseJson.toString(2));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void writeNewClassroomCapacity(Classroom cr,int newCapacity){

        String filePath = "jsonfiles/"+"classrooms"+".json";
        try {
            // Read and parse the JSON file
            FileReader reader = new FileReader(filePath);
            StringBuilder jsonContent = new StringBuilder();
            int c;
            while ((c = reader.read()) != -1) {
                jsonContent.append((char) c);
            }
            reader.close();

            // Parse the content into a JSONObject
            JSONObject classes = new JSONObject(jsonContent.toString());

            // Access and modify the "selectedCourseSections" array
            JSONArray classrooms = classes.getJSONArray("courseSections");


            for (int i = 0; i < classrooms.length(); i++) {
                JSONObject classroom = classrooms.getJSONObject(i);
                if (classroom.getString("name").equals(cr.getRoomID())) {

                    classroom.put("capacity", newCapacity);

                    break;
                }
            }


            // Write the updated JSONObject back to the file
            try (FileWriter writer = new FileWriter(filePath)) {
                writer.write(classes.toString(2));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void updateCourseSectionDateAndTime(CourseSection cs,String day,String time){

        String id = cs.getCourse().getCourseCode();
        String filePath = "jsonfiles/"+id+".json";




        try {
            // Read and parse the JSON file
            FileReader reader = new FileReader(filePath);
            StringBuilder jsonContent = new StringBuilder();
            int c;
            while ((c = reader.read()) != -1) {
                jsonContent.append((char) c);
            }
            reader.close();

            // Parse the content into a JSONObject
            JSONObject courseJson = new JSONObject(jsonContent.toString());

            // Access and modify the "selectedCourseSections" array
            JSONArray courseSections = courseJson.getJSONArray("courseSections");


            for (int i = 0; i < courseSections.length(); i++) {
                JSONObject section = courseSections.getJSONObject(i);
                if (section.getString("sectionNumber").equals(cs.getSectionNumber())) {

                    section.put("day", day);
                    section.put("time", time);

                    break; // Exit the loop after updating
                }
            }


            // Write the updated JSONObject back to the file
            try (FileWriter writer = new FileWriter(filePath)) {
                writer.write(courseJson.toString(2));
            }

        } catch (IOException e) {
            e.printStackTrace();
        }



    }



    }



