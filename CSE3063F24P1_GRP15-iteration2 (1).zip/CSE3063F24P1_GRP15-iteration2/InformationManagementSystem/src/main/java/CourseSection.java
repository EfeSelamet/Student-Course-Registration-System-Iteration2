import java.util.LinkedList;
import java.util.Queue;

public class CourseSection {

	private String day;
	private String hour;
	private int sectionNumber;
	private int capacity;
	private int numberOfStudents;
	private String id;
	private Course course;
	private Classroom classroom;
	private Queue<Student> waitingStudents;


	public CourseSection(String day, String hour, int sectionNumber, Course course, Classroom classroom){
		this.classroom = classroom;
		this.course = course;
		this.day = day;
		this.hour = hour;
		this.sectionNumber = sectionNumber;
		this.waitingStudents = new LinkedList<>();
		this.numberOfStudents=0;

	}
	public CourseSection(){
		this.waitingStudents = new LinkedList<>();
		this.numberOfStudents=0;
	}

	public void setClassroom(Classroom classroom) {
		this.classroom = classroom;
	}
	public void setDay(String day) {
		this.day = day;
	}public void setHour(String hour) {
		this.hour = hour;
	}

	public Classroom getClassroom() {
		return classroom;
	}
	public int getCapacity() {
		return capacity;
	}
	public Course getCourse() {
		return course;
	}
	public String getDay() {
		return day;
	}

	public String getHour() {
		return hour;
	}
	public int getSectionNumber() {
		return sectionNumber;
	}
	public Queue<Student> getwaitingStudents() {
		return waitingStudents;
	}
	public void setSectionNumber(int sectionNumber){
		this.sectionNumber =sectionNumber;
	}

	public String getId(){
		return this.id;
	}

	public void setCapacityAndEnrollStudent(int newCapacity){

		for(int i=0;i<(newCapacity-this.capacity)&&waitingStudents.size()>0;i++){
			Student student = waitingStudents.remove();

			student.getTranscript().addSelectedCourse(this);
		}

		this.capacity=newCapacity;
	}

	public int getNumberOfStudents() {
		return numberOfStudents;
	}

	public void setNumberOfStudents(int numberOfStudents) {
		this.numberOfStudents = numberOfStudents;
	}

	public void setId(String id) {
		this.id = id;
	}
	public void setCourse(Course course){
		this.course = course;
	}
}
