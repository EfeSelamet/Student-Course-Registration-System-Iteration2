import java.util.ArrayList;
import java.util.HashSet;

public class Classroom {
	private int capacity;
	private String roomID;
	private ArrayList<CourseSection> courseSections=new ArrayList<>();
	
	public Classroom(int capacity, String roomID){
		this.capacity = capacity;
		this.roomID = roomID;
	}



	public boolean checkLocationConflict(String day,String hour) {
		HashSet<Integer> hourList1 = new HashSet<>();
		HashSet<Integer> hourList2 = new HashSet<>();
		ArrayList<String> days = new ArrayList<>();
		for (int i = 0; i < courseSections.size(); i++) {
			CourseSection section1 = courseSections.get(i);
			int startHour = Integer.parseInt(section1.getHour().substring(0, 2));
			int endHour = Integer.parseInt(section1.getHour().substring(6, 8));
			days.add(courseSections.get(i).getDay());
			// Create a list to hold the hour values

			for (int a = startHour; a <= endHour; a++) {
				hourList1.add(a);
			}



		}
		int startHour2 = Integer.parseInt(hour.substring(0, 2));
		int endHour2 = Integer.parseInt(hour.substring(6, 8));

		for (int b = startHour2; b <= endHour2; b++) {
			hourList2.add(b);
		}

		hourList1.retainAll(hourList2);

		return hourList1.isEmpty()&&days.contains(day);


	}


	public String getRoomID() {
		return roomID;
	}

	public void removeCourseSection(CourseSection cs){
		this.courseSections.remove(cs);
	}

	public void setRoomID(String roomID) {
		this.roomID = roomID;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
	public void addCourseSection(CourseSection cs){
		this.courseSections.add(cs);
	}
}
