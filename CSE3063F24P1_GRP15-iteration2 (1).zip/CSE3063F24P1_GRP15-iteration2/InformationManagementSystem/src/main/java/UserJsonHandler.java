import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.json.*;
class UserJsonHandler implements JsonHandler {
	

	private String parameters;

	public UserJsonHandler(){
		this.parameters="jsonfiles/parameters.json";
	}


	public String checkUser(String userName, String password) {

        try {
            FileReader reader = new FileReader(parameters);
			Scanner scanner = new Scanner(reader);
			StringBuilder jsonContent = new StringBuilder();

			while (scanner.hasNextLine()) {
				jsonContent.append(scanner.nextLine());
			}
			scanner.close();
			JSONArray usersArray = new JSONArray(jsonContent.toString());

			for (int i = 0; i < usersArray.length(); i++) {
				JSONObject user = usersArray.getJSONObject(i);

				String storedUsername = user.getString("username");
				String storedPassword = user.getString("password");

				if (storedUsername.equals(userName) && storedPassword.equals(password)) {
					return user.getString("userId");
				}
			}


		} catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        return "";
	}
	public void writeAllSelectedCourses(Student student,ArrayList<CourseSection> csList){
		for(CourseSection cs:csList){
			writeSelectedCoursesSection(student,cs);

		}


	}

	public void writeSelectedCoursesSection(Student student,CourseSection cs){

		String id = student.getID();
		String filePath = "jsonfiles/"+id+".json";


		try {
			// Read and parse the JSON file
			FileReader reader = new FileReader(filePath);
			StringBuilder jsonContent = new StringBuilder();
			int c;
			while ((c = reader.read()) != -1) {
				jsonContent.append((char) c);
			}
			reader.close();

			// Parse the content into a JSONObject
			JSONObject jsonObject = new JSONObject(jsonContent.toString());

			// Access and modify the "selectedCourseSections" array
			JSONArray selectedCourseSections = jsonObject.getJSONArray("selectedCourseSections");


			selectedCourseSections.put(cs.getId());

			student.getTranscript().addSelectedCourse(cs);

			// Write the updated JSONObject back to the file
			try (FileWriter file = new FileWriter(filePath)) {
				file.write(jsonObject.toString(4)); // Indented with 4 spaces

			}

		} catch (IOException e) {
			e.printStackTrace();
		}


    }

	public void writeVerifiedCourseSection(Student student,CourseSection cs){

		String id = student.getID();
		String filePath = "jsonfiles/"+id+".json";

		try {
			// Read and parse the JSON file
			FileReader reader = new FileReader(filePath);
			StringBuilder jsonContent = new StringBuilder();
			int c;
			while ((c = reader.read()) != -1) {
				jsonContent.append((char) c);
			}
			reader.close();

			// Parse the content into a JSONObject
			JSONObject jsonObject = new JSONObject(jsonContent.toString());

			// Access and modify the "selectedCourseSections" array
			JSONArray CourseSections = jsonObject.getJSONArray("verifiedCourseSections");


			CourseSections.put(cs.getId());



			// Write the updated JSONObject back to the file
			try (FileWriter file = new FileWriter(filePath)) {
				file.write(jsonObject.toString(4)); // Indented with 4 spaces

			}

		} catch (IOException e) {
			e.printStackTrace();
		}



	}

	public void removeSelectedCoursesSections(Student student,CourseSection cs){
		String id = student.getID();
		String filePath = "jsonfiles/"+id+".json";
		try {
			// Read and parse the JSON file
			FileReader reader = new FileReader(filePath);
			StringBuilder jsonContent = new StringBuilder();
			int c;
			while ((c = reader.read()) != -1) {
				jsonContent.append((char) c);
			}
			reader.close();

			// Parse the content into a JSONObject
			JSONObject jsonObject = new JSONObject(jsonContent.toString());

			// Access the "selectedCourseSections" array
			JSONArray selectedCourseSections = jsonObject.getJSONArray("selectedCourseSections");

			// Strings to remove
			String courseToRemove = cs.getId();


			// Remove specified courses

				for (int i = 0; i < selectedCourseSections.length(); i++) {
					if (selectedCourseSections.getString(i).equals(courseToRemove)) {
						selectedCourseSections.remove(i);
						break;
					}
				}


			// Write the updated JSONObject back to the file
			try (FileWriter file = new FileWriter(filePath)) {
				file.write(jsonObject.toString(4)); // Indented with 4 space
			}

		} catch (IOException e) {
			e.printStackTrace();
		}




	}
















	



	public ArrayList<String> retrieveInfo(String id){
		String fileName = "jsonfiles/"+id+".json";
		ArrayList<String> infos = new ArrayList<>();

        FileReader reader = null;
        try {
            reader = new FileReader(fileName);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        Scanner scanner = new Scanner(reader);
		StringBuilder jsonContent = new StringBuilder();
		while (scanner.hasNextLine()) {
			jsonContent.append(scanner.nextLine());
		}
		scanner.close();
		JSONObject jsonObject = new JSONObject(jsonContent.toString());

		String type = jsonObject.getString("type");
		switch(type){
			case "student":
				infos.add(type);
				infos.add(jsonObject.getString("name"));
				infos.add(jsonObject.getString("advisorId"));
				JSONArray selectedCourses = jsonObject.getJSONArray("selectedCourseSections");
				String fcc = "";
				
				for (int i = 0; i < selectedCourses.length(); i++) {
					if (i > 0) fcc+=",";
					fcc+=selectedCourses.getString(i);
				}
				infos.add(fcc);



				JSONArray verifiedCourses = jsonObject.getJSONArray("verifiedCourseSections");
				String fcc2 = "";
				
				for (int i = 0; i < verifiedCourses.length(); i++) {
					if (i > 0) fcc2+=",";
					fcc2+=verifiedCourses.getString(i);
				}
				infos.add(fcc2);
				


				JSONArray finishedCourses = jsonObject.getJSONArray("finishedCourses");
				String fcc3 = "";
				
				for (int i = 0; i < finishedCourses.length(); i++) {
					if (i > 0) fcc3+=",";
					fcc3+=finishedCourses.getString(i);
				}
				infos.add(fcc3);
				break;

			case "advisor":
				infos.add(jsonObject.getString("type"));

				// Add the "name" field
				infos.add(jsonObject.getString("name"));


				JSONArray studentArray = jsonObject.getJSONArray("students");
				StringBuilder students = new StringBuilder();
				for (int i = 0; i < studentArray.length(); i++) {
					if (i > 0) students.append(",");
					students.append(studentArray.getString(i));
				}
				infos.add(students.toString());
				break;

			case "scheduler":

				infos.add(jsonObject.getString("type"));

				// Add the "name" field
				infos.add(jsonObject.getString("name"));
				break;



		}

		return infos;
	}
	
}
