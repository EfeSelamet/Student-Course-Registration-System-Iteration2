import java.util.ArrayList;

public interface JsonHandler {

    public ArrayList<String> retrieveInfo(String id);




}
