import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Course {

	private ArrayList<CourseSection> courseSections=new ArrayList<>();
	private ArrayList<Course> prerequisiteCourse=new ArrayList<>();
	private String courseCode;
	private String year;
	private String name;
	
	//course section oluşturmak için JSON lazım

	public String getName() {
		return name;
	}
	public String getCourseCode() {
		return courseCode;
	}
	public void addPrerequisite(Course c){
		this.prerequisiteCourse.add(c);
	}

	public void setCourseCode(String CourseCode){
		this.courseCode = CourseCode;
	}
	public ArrayList<CourseSection> getCourseSections() {
		return courseSections;
	}
	public Course(ArrayList<Course> prerequisiteCourse, String courseCode) {
		this.prerequisiteCourse = prerequisiteCourse;
		this.courseCode = courseCode;
	}
	public Course(){

	}
	public void addCourseSection(CourseSection cs){
		courseSections.add(cs);
	}
	
	public boolean checkPrerequisites (Student student) {
		Transcript transcript = student.getTranscript();
		HashMap<Course, Float> finishedCourses = transcript.getFinishedCourses();
		for(Course i: prerequisiteCourse){
			for(Map.Entry<Course, Float> set: finishedCourses.entrySet()){
				if(set.getKey().getCourseCode().equals(i.courseCode)){
					continue;
				}
				}
			return false;
		}
		return true;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCourseSections(ArrayList<CourseSection> courseSections) {
		this.courseSections = courseSections;
	}

	public void setYear(String year) {
		this.year = year;
	}
}
