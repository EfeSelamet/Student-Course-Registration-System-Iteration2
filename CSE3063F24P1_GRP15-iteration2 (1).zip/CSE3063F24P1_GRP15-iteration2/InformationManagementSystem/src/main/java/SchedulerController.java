import java.util.ArrayList;

public class SchedulerController{
    public String viewCourses()
    {
        ArrayList<Course> listOfCourses= RegistrationController.getRegistrationController().getAllCourses();
        String courseList = "";
        int number = 1;

        for(Course course: listOfCourses){
            courseList += number + ". " + course.getCourseCode() + " " + course.getName()  + "\n";
            number++;
        }

        return courseList;
    }

    public String viewCourseSections(int index)
    {
        ArrayList<Course> listOfCourses= RegistrationController.getRegistrationController().getAllCourses();
        if(index < 1 || index > listOfCourses.size())
            return null;

        Course selectedCourse = listOfCourses.get(index);
        String sectionList = "";
        int number = 1;

        for(CourseSection section: selectedCourse.getCourseSections()){
            sectionList += number + ". " + section.getId() + " " + section.getDay() + " " + section.getHour() + " Capacity:"+ section.getCapacity() +"\n";
            number++;
        }

        return sectionList;
    }

    public boolean editSectionCapacity(int course, int section, int capacity)
    {
        ArrayList<Course> listOfCourses= RegistrationController.getRegistrationController().getAllCourses();
        ArrayList<CourseSection> listOfSections = listOfCourses.get(course-1).getCourseSections();
        if(section < 1 || section > listOfCourses.size())
            return false;

        CourseSection courseSection = listOfSections.get(section-1);
        courseSection.setCapacityAndEnrollStudent(capacity);


        CourseJsonHandler csj = new CourseJsonHandler();

        csj.writeCapacity(courseSection,capacity);

        return true;
    }

    public boolean editSectionTime(int course, int section, String time, String date)
    {
        ArrayList<Course> listOfCourses= RegistrationController.getRegistrationController().getAllCourses();
        ArrayList<CourseSection> listOfSections = listOfCourses.get(course-1).getCourseSections();
        CourseScheduler scheduler= (CourseScheduler)LoginSystemController.getLoginSystem().getCurrentUser(); 
        if(section < 1 || section > listOfCourses.size())
            return false;

        CourseSection courseSection = listOfSections.get(section-1);




        return scheduler.editSectionTime(courseSection, time, date);
    }

    public boolean editSectionClass(int course, int section, String classroom)
    {
        ArrayList<Course> listOfCourses= RegistrationController.getRegistrationController().getAllCourses();
        ArrayList<Classroom> allClassrooms = RegistrationController.getRegistrationController().getAllClassrooms();
        ArrayList<CourseSection> listOfSections = listOfCourses.get(course-1).getCourseSections();
        CourseScheduler scheduler= (CourseScheduler)LoginSystemController.getLoginSystem().getCurrentUser(); 
        if(section < 1 || section > listOfCourses.size())
            return false;


        CourseJsonHandler csj = new CourseJsonHandler();
        CourseSection courseSection = listOfSections.get(section-1);
        Classroom oldCr = courseSection.getClassroom();
        oldCr.removeCourseSection(courseSection);
        for(Classroom cr: allClassrooms){
            if(cr.getRoomID().equals(classroom)){
                Classroom newCr =cr;
                if(cr.getCapacity()<courseSection.getCapacity()){
                    System.out.println("warning: course section capacity will exceed class capacity");
                    cr.setCapacity(courseSection.getCapacity());
                    csj.writeNewClassroomCapacity(cr,courseSection.getCapacity());
                }
                newCr.addCourseSection(courseSection);
                courseSection.setClassroom(newCr);
                break;

            }
        }




        csj.writeClassroom(courseSection,classroom);
       return true;
    }


    public boolean addCourseSection(int course,int capacity,String classroom, String hour,String day){
        ArrayList<Course> listOfCourses =RegistrationController.getRegistrationController().getAllCourses();
        if(course < 1 || course > listOfCourses.size())
            return false;
        Course c = listOfCourses.get(course-1);
        CourseScheduler scheduler= (CourseScheduler)LoginSystemController.getLoginSystem().getCurrentUser();




        return scheduler.addSection(c.getCourseCode(),capacity+"",classroom,hour,day);

    }
}
