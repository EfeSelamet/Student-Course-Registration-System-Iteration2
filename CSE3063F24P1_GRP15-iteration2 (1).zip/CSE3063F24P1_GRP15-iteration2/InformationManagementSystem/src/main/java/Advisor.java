import java.util.ArrayList;

public class Advisor extends Person {

	private ArrayList<Student> students;
	private UserJsonHandler userJson = new UserJsonHandler();
	public Advisor(ArrayList<String> infos,String advisorId)
	{
		super(infos.get(1),advisorId);
		this.students = new ArrayList<Student>();
	}
	
	public void sendVerifiedCourses(Transcript transcript, ArrayList<CourseSection> verifiedCourses){
		Student student = transcript.getStudent();
		for(CourseSection i: verifiedCourses){
			transcript.addVerifiedCourse(i);
			userJson.writeVerifiedCourseSection(student,i);

		}
	}

	public void sendRejectedCourses(Transcript transcript, ArrayList<CourseSection> rejectedCourses){
		Student student = transcript.getStudent();
		for(CourseSection i: rejectedCourses){
			transcript.removeSelectedCourse(i);
			userJson.removeSelectedCoursesSections(student, i);
		}
	}

	public ArrayList<Student> getStudentList(){
		return students;
	}

	public void addStudent(Student student) {
		this.students.add(student);
	}

	@Override
	public void mainMenu(UserInterface userInterface) {
		userInterface.AdvisorMainScreen();
	}
}
