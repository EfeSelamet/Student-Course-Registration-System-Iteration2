import java.util.ArrayList;
import java.util.HashMap;

public class Transcript {

	private ArrayList<CourseSection> selectedCourses;
	private ArrayList<CourseSection> verifiedCourses;
	private HashMap<Course, Float> FinishedCourses;
	private Student student;

	public Transcript(ArrayList<CourseSection> selectedCourses, ArrayList<CourseSection> verifiedCourses, HashMap<Course, Float> FinishedCourses, Student student){
		this.selectedCourses = selectedCourses;
		this.verifiedCourses = verifiedCourses;
		this.FinishedCourses = FinishedCourses;
		this.student = student;
	}

	public void setSelectedCourses (ArrayList<CourseSection> selectedCourseSections) {
		this.selectedCourses = selectedCourseSections;
	}
	public void setVerifiedCourses(ArrayList<CourseSection> verifiedCourses) {
		this.verifiedCourses = verifiedCourses;
	}
	public void addSelectedCourse(CourseSection section){
		selectedCourses.add(section);
	}
	public HashMap<Course, Float> getFinishedCourses() {
		return FinishedCourses;
	}
	public ArrayList<CourseSection> getSelectedCourses() {
		return selectedCourses;
	}
	public Student getStudent() {
		return student;
	}
	public ArrayList<CourseSection> getVerifiedCourses() {
		return verifiedCourses;
	}

	public void addVerifiedCourse(CourseSection verifiedCourse){
		verifiedCourses.add(verifiedCourse);
	}

	public void removeSelectedCourse(CourseSection rejectedCourse){
		String rejectedCourseCode = rejectedCourse.getCourse().getCourseCode();
		for(CourseSection i: selectedCourses){
			if(i.getCourse().getCourseCode() == rejectedCourseCode){
				selectedCourses.remove(i);
				break;
			}
		}
	}
	public String toString() {
		String result = "";
		for (HashMap.Entry<Course, Float> entry : FinishedCourses.entrySet()) {
			result += "Course: " + entry.getKey().getName() + ", Grade: " + entry.getValue() + "\n";
		}
		return result;
	}



}
