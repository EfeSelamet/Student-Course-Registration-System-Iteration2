import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

public class SchedulerContreollerTest {
    @Test
    void editSectionClass(){
        LoginSystemController logCon = new LoginSystemController();
        RegistrationController regCon = new RegistrationController();
        //CourseScheduler scheduler = (CourseScheduler)logCon.createUser("3001");
        SchedulerController scheduler = new SchedulerController();
        int courseNumber = 3;
        int sectionNumber = 2;
        String classroom = "M2.Z11";
        assertEquals(true, scheduler.editSectionClass(courseNumber,sectionNumber,classroom));
    }
}
