import static org.junit.jupiter.api.Assertions.*;


import java.util.ArrayList;

import org.junit.jupiter.api.*;

public class RegistrationControllerTest {
    @Test
    //To check if the RegisterController class is create all of the course objects
    void createAllCoursesTest(){
        RegistrationController regCon = new RegistrationController();
        String expectedCourseCodes[] = {"CSE1200","CSE1242","CSE2022","CSE2138","CSE2225","CSE3033","CSE4074","CSE4288"};

        String courseCodes[] = new String[8];
        ArrayList<Course> allCourses = regCon.getAllCourses();
        int i = 0;
        for (Course course : allCourses) {
            courseCodes[i] = course.getCourseCode();
            i++;
        }
        assertArrayEquals(expectedCourseCodes, courseCodes);
    }
}
