import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

public class loginSystemControllerTest {
    @Test
    void userCreateTest(){
        LoginSystemController logCon = new LoginSystemController();
        RegistrationController regCon = new RegistrationController();
        Advisor advisor = (Advisor)logCon.createUser("2002");
        Student expectedStudent = (Student)logCon.createUser("1005");
        Student student = advisor.getStudentList().get(0);

        assertEquals(expectedStudent.getID(), student.getID());
    }
}
