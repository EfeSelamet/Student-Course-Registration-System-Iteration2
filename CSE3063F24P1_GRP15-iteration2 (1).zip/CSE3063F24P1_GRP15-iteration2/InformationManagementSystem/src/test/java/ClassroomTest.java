import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.*;

public class ClassroomTest {
    @Test
    void checkLocationConflictTest(){
        RegistrationController regCon = new RegistrationController();
        ArrayList<Classroom> allClassrooms = regCon.getAllClassrooms();

        Classroom classroom = allClassrooms.get(0);
        String day = "Tuesday";
        String time = "10:00-10:50";
        
        assertEquals(false, classroom.checkLocationConflict(day,time));
    }
}
