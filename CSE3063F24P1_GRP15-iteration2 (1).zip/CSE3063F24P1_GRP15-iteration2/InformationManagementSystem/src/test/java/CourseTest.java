import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

public class CourseTest {
    
    @Test
    void checkPrerequisitesTest(){ 
        RegistrationController regCon = new RegistrationController();
        ArrayList<Course> allCourses= regCon.getAllCourses();

        Course newCourse = allCourses.get(7);
        
        LoginSystemController logCon = new LoginSystemController();
        Student student = (Student)logCon.createUser("1007");

        assertEquals(true, newCourse.checkPrerequisites(student));
    }
}
